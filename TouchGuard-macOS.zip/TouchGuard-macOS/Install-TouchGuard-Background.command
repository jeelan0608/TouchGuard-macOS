#!/bin/zsh
set -euo pipefail

pause_before_close() {
  read -r "REPLY?Press Return to close this window..."
}

fail() {
  echo ""
  echo "TouchGuard could not finish installing the background helper."
  echo "$1"
  echo ""
  pause_before_close
  exit 1
}

SCRIPT_DIR="${0:A:h}"
APP_PATH="$SCRIPT_DIR/TouchGuard.app"
AGENT_PATH="$APP_PATH/Contents/Library/LoginItems/TouchGuardAgent.app/Contents/MacOS/TouchGuardAgent"
AGENT_LABEL="com.codex.touchguard.agent"
AGENT_PLIST="$HOME/Library/LaunchAgents/$AGENT_LABEL.plist"

if [[ ! -x "$AGENT_PATH" ]]; then
  fail "TouchGuard.app must stay beside this installer. Move both items to Applications or another folder and try again."
fi

AGENT_APP="${AGENT_PATH%/Contents/MacOS/TouchGuardAgent}"
if [[ ! -f "$AGENT_APP/Contents/Info.plist" ]]; then
  fail "The background helper bundle is incomplete. Please reopen TouchGuard and try again."
fi

mkdir -p "$HOME/Library/LaunchAgents" "$HOME/Library/Logs" \
  || fail "macOS would not allow TouchGuard to create its background service files."
if ! cat > "$AGENT_PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$AGENT_LABEL</string>
  <key>ProgramArguments</key><array><string>$AGENT_PATH</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>LimitLoadToSessionType</key><string>Aqua</string>
  <key>StandardOutPath</key><string>$HOME/Library/Logs/TouchGuardAgent.log</string>
  <key>StandardErrorPath</key><string>$HOME/Library/Logs/TouchGuardAgent.log</string>
</dict>
</plist>
PLIST
then
  fail "macOS would not allow TouchGuard to save its background service settings."
fi

launchctl bootout "gui/$(id -u)" "$AGENT_PLIST" 2>/dev/null || true
if ! launchctl bootstrap "gui/$(id -u)" "$AGENT_PLIST" 2>/dev/null; then
  launchctl kickstart -k "gui/$(id -u)/$AGENT_LABEL" \
    || fail "macOS could not start the background helper."
fi
defaults write com.codex.touchguard protectionEnabled -bool true

echo "TouchGuard background protection is installed and running."
echo "It will restart at login."
echo ""
pause_before_close
