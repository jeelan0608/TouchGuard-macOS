import AppKit
import LocalAuthentication

private struct ProtectedApp: Decodable {
    let bundleID: String
    let name: String
    let path: String?
}

private struct ProtectionSchedule: Decodable {
    let isEnabled: Bool
    let days: Set<Int>
    let startMinute: Int
    let endMinute: Int
}

@MainActor
private final class LaunchGuard {
    private var observer: NSObjectProtocol?
    private var poller: Timer?
    private var handledPIDs = Set<pid_t>()
    private var pendingPIDs = Set<pid_t>()
    private var pendingBundleIDs = Set<String>()
    private var authorizedRelaunches = Set<String>()

    init() {
        let config = UserDefaults(suiteName: "com.codex.touchguard") ?? .standard
        let configured = (config.data(forKey: "protectedApps")
            .flatMap { try? JSONDecoder().decode([ProtectedApp].self, from: $0) }) ?? []
        NSLog("TouchGuard agent ready; bundle=%@; protected app count=%d",
              Bundle.main.bundleIdentifier ?? "unknown", configured.count)
        observer = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didLaunchApplicationNotification,
            object: nil,
            queue: .main
        ) { [weak self] note in
            guard let app = note.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication else { return }
            Task { @MainActor in self?.check(app) }
        }
        poller = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in
                for running in NSWorkspace.shared.runningApplications { self?.check(running) }
            }
        }
    }

    private func check(_ app: NSRunningApplication) {
        let settings = UserDefaults(suiteName: "com.codex.touchguard") ?? .standard
        if settings.object(forKey: "protectionEnabled") as? Bool == false { return }
        guard scheduleIsActive(settings) else { return }
        guard let bundleID = app.bundleIdentifier,
              let data = settings.data(forKey: "protectedApps"),
              let protectedApps = try? JSONDecoder().decode([ProtectedApp].self, from: data),
              protectedApps.contains(where: { $0.bundleID == bundleID }) else { return }

        if authorizedRelaunches.remove(bundleID) != nil {
            handledPIDs.insert(app.processIdentifier)
            NSLog("TouchGuard opened authenticated app %@", bundleID)
            return
        }
        if pendingBundleIDs.contains(bundleID) {
            guard !pendingPIDs.contains(app.processIdentifier) else { return }
            NSLog("TouchGuard closing duplicate launch while %@ is awaiting authentication", bundleID)
            app.terminate()
            return
        }
        guard !handledPIDs.contains(app.processIdentifier),
              !pendingPIDs.contains(app.processIdentifier) else { return }

        NSLog("TouchGuard agent protecting %@ (%@)", app.localizedName ?? "app", bundleID)
        let pid = app.processIdentifier
        let configuredPath = protectedApps.first(where: { $0.bundleID == bundleID })?.path
        let appURL = app.bundleURL ?? configuredPath.map { URL(fileURLWithPath: $0) }
        pendingPIDs.insert(pid)
        pendingBundleIDs.insert(bundleID)
        // Close the process before authentication. A successful check relaunches
        // it through a one-use authorization token so its launch isn't challenged again.
        app.terminate()

        let context = LAContext()
        context.localizedCancelTitle = "Cancel"
        context.localizedFallbackTitle = "More Options"
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            NSLog("TouchGuard authentication unavailable for %@: %@", bundleID, error?.localizedDescription ?? "unknown")
            close(app)
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication,
                               localizedReason: "Unlock \(app.localizedName ?? "this app")") { [weak self] success, _ in
            Task { @MainActor in
                guard let self else { return }
                self.pendingPIDs.remove(pid)
                self.pendingBundleIDs.remove(bundleID)
                if success {
                    NSLog("TouchGuard authenticated %@", bundleID)
                    guard let appURL else {
                        NSLog("TouchGuard could not find the app bundle for %@", bundleID)
                        return
                    }
                    self.authorizedRelaunches.insert(bundleID)
                    let configuration = NSWorkspace.OpenConfiguration()
                    configuration.activates = true
                    NSWorkspace.shared.openApplication(at: appURL, configuration: configuration) { [weak self] reopened, error in
                        Task { @MainActor in
                            guard let self else { return }
                            if let reopened {
                                self.handledPIDs.insert(reopened.processIdentifier)
                                NSLog("TouchGuard reopened authenticated app %@", bundleID)
                            } else {
                                self.authorizedRelaunches.remove(bundleID)
                                NSLog("TouchGuard could not reopen %@: %@", bundleID, error?.localizedDescription ?? "unknown error")
                            }
                        }
                    }
                } else {
                    NSLog("TouchGuard authentication failed for %@", bundleID)
                }
            }
        }
    }

    private func scheduleIsActive(_ settings: UserDefaults) -> Bool {
        if let expiration = settings.object(forKey: "proExpirationDate") as? Date,
           expiration <= Date() {
            return true
        }
        guard let data = settings.data(forKey: "protectionSchedules"),
              let schedules = try? JSONDecoder().decode([ProtectionSchedule].self, from: data) else { return true }
        let enabled = schedules.filter(\.isEnabled)
        guard !enabled.isEmpty else { return true }

        let calendar = Calendar.current
        let parts = calendar.dateComponents([.weekday, .hour, .minute], from: Date())
        guard let weekday = parts.weekday, let hour = parts.hour, let minute = parts.minute else { return false }
        let currentMinute = hour * 60 + minute
        return enabled.contains { schedule in
            guard !schedule.days.isEmpty else { return false }
            if schedule.startMinute == schedule.endMinute {
                return schedule.days.contains(weekday)
            }
            if schedule.startMinute < schedule.endMinute {
                return schedule.days.contains(weekday)
                    && currentMinute >= schedule.startMinute && currentMinute < schedule.endMinute
            }
            if currentMinute >= schedule.startMinute { return schedule.days.contains(weekday) }
            if currentMinute < schedule.endMinute {
                let previousWeekday = weekday == 1 ? 7 : weekday - 1
                return schedule.days.contains(previousWeekday)
            }
            return false
        }
    }

    private func close(_ app: NSRunningApplication) {
        pendingPIDs.remove(app.processIdentifier)
        if let bundleID = app.bundleIdentifier {
            pendingBundleIDs.remove(bundleID)
        }
        app.terminate()
    }

}

@main
private enum TouchGuardAgentMain {
    @MainActor
    static func main() {
        let application = NSApplication.shared
        application.setActivationPolicy(.accessory)
        let guardService = LaunchGuard()
        withExtendedLifetime(guardService) {
            application.run()
        }
    }
}
