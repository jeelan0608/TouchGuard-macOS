import AppKit
import CryptoKit
import LocalAuthentication
import SwiftUI
import UniformTypeIdentifiers

struct ProtectedApp: Identifiable, Codable, Hashable {
    var id: String { bundleID }
    let bundleID: String
    let name: String
    let path: String
}

struct ProtectionSchedule: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var isEnabled = true
    var days: Set<Int> = [2, 3, 4, 5, 6]
    var startMinute = 9 * 60
    var endMinute = 17 * 60
}

@MainActor
final class GuardModel: ObservableObject {
    @Published private(set) var apps: [ProtectedApp] = []
    @Published private(set) var status = "Protection is off."
    @Published private(set) var protectionEnabled = false
    @Published var showingPro = false
    @Published var showingSchedule = false
    @Published var activationInput = ""
    @Published private(set) var isPro = false
    @Published private(set) var proExpirationDate: Date?
    @Published private(set) var proActivationMessage: String?
    @Published private(set) var schedules: [ProtectionSchedule] = {
        guard let data = UserDefaults.standard.data(forKey: "protectionSchedules"),
              let schedules = try? JSONDecoder().decode([ProtectionSchedule].self, from: data) else { return [] }
        return schedules
    }()
    private let defaultsKey = "protectedApps"
    private let protectionKey = "protectionEnabled"
    private let installCodeKey = "touchguard.license.installCode"
    private let proExpirationKey = "touchguard.pro.expiration"
    private var proExpiryTimer: Timer?

    var proPlanLabel: String {
        guard isPro, let proExpirationDate else { return isPro ? "TouchGuard Pro" : "Free plan · 1 app" }
        return "TouchGuard Pro · expires \(proExpirationDate.formatted(date: .abbreviated, time: .omitted))"
    }

    var activationRequestCode: String {
        if let existing = UserDefaults.standard.string(forKey: installCodeKey) { return existing }
        let value = UUID().uuidString.replacingOccurrences(of: "-", with: "")
        UserDefaults.standard.set(value, forKey: installCodeKey)
        return value
    }

    func activatePro(with code: String) {
        let parts = code.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: ".", maxSplits: 1)
        guard parts.count == 2,
              let expirationTimestamp = TimeInterval(parts[0]),
              let signature = Self.decodeBase64URL(String(parts[1])),
              let publicKeyData = Self.decodeBase64URL("OrW-ZLcSbQvWPWiyqWcrc2Gec4pnX6ne-3kB64BzP18"),
              let publicKey = try? Curve25519.Signing.PublicKey(rawRepresentation: publicKeyData),
              Date(timeIntervalSince1970: expirationTimestamp) > Date(),
              publicKey.isValidSignature(signature, for: Data("\(activationRequestCode):\(Int64(expirationTimestamp))".utf8)) else {
            proActivationMessage = "That code is not valid for this Mac. Check it and try again."
            return
        }
        let expiration = Date(timeIntervalSince1970: expirationTimestamp)
        proExpirationDate = expiration
        isPro = true
        UserDefaults.standard.set(true, forKey: "touchguard.pro")
        UserDefaults.standard.set(expiration, forKey: proExpirationKey)
        UserDefaults(suiteName: "com.codex.touchguard")?.set(expiration, forKey: "proExpirationDate")
        activationInput = ""
        proActivationMessage = "TouchGuard Pro is active on this Mac."
    }

    private static func decodeBase64URL(_ value: String) -> Data? {
        var base64 = value.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        let padding = (4 - base64.count % 4) % 4
        base64 += String(repeating: "=", count: padding)
        return Data(base64Encoded: base64)
    }

    init() {
        if let data = UserDefaults.standard.data(forKey: defaultsKey),
           let saved = try? JSONDecoder().decode([ProtectedApp].self, from: data) {
            apps = saved
        }
        refreshProStatus()
        proExpiryTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in self?.refreshProStatus() }
        }
        let storedSetting = UserDefaults.standard.object(forKey: protectionKey) as? Bool
        protectionEnabled = storedSetting ?? BackgroundAgentInstaller.isInstalled
        if protectionEnabled {
            status = "Starting background protection…"
            Task { [weak self] in
                let result = await Task.detached(priority: .userInitiated) {
                    BackgroundAgentInstaller.install()
                }.value
                guard let self else { return }
                self.status = result
                self.protectionEnabled = result.hasPrefix("Background protection is running")
                UserDefaults.standard.set(self.protectionEnabled, forKey: self.protectionKey)
            }
        }
    }

    func setProtectionEnabled(_ enabled: Bool) {
        guard protectionEnabled != enabled else { return }
        if enabled {
            status = "Starting background protection…"
            Task { [weak self] in
                let result = await Task.detached(priority: .userInitiated) {
                    BackgroundAgentInstaller.install()
                }.value
                guard let self else { return }
                self.status = result
                self.protectionEnabled = result.hasPrefix("Background protection is running")
                UserDefaults.standard.set(self.protectionEnabled, forKey: self.protectionKey)
            }
        } else {
            status = "Turning off protection…"
            Task { [weak self] in
                let result = await Task.detached(priority: .userInitiated) {
                    BackgroundAgentInstaller.uninstall()
                }.value
                guard let self else { return }
                self.status = result
                self.protectionEnabled = false
                UserDefaults.standard.set(false, forKey: self.protectionKey)
            }
        }
    }

    func addApp() {
        guard isPro || apps.isEmpty else { showingPro = true; return }
        let panel = NSOpenPanel()
        panel.title = "Choose an app to protect"
        panel.message = "Select an application from Applications."
        panel.allowedContentTypes = [.application]
        panel.allowsMultipleSelection = isPro
        guard panel.runModal() == .OK else { return }
        for url in (isPro ? panel.urls : Array(panel.urls.prefix(1))) {
            guard let bundle = Bundle(url: url), let bundleID = bundle.bundleIdentifier else { continue }
            let item = ProtectedApp(bundleID: bundleID,
                                    name: bundle.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String
                                        ?? bundle.object(forInfoDictionaryKey: "CFBundleName") as? String
                                        ?? url.deletingPathExtension().lastPathComponent,
                                    path: url.path)
            if !apps.contains(where: { $0.bundleID == bundleID }) { apps.append(item) }
        }
        save()
    }

    func requestSchedule() {
        guard isPro else { showingPro = true; return }
        showingSchedule = true
    }

    func addSchedule() {
        schedules.append(ProtectionSchedule(name: "Schedule \(schedules.count + 1)"))
        saveSchedules()
    }

    func updateSchedule(_ updated: ProtectionSchedule) {
        guard let index = schedules.firstIndex(where: { $0.id == updated.id }) else { return }
        schedules[index] = updated
        saveSchedules()
    }

    func removeSchedule(_ id: UUID) {
        schedules.removeAll { $0.id == id }
        saveSchedules()
    }

    func remove(_ app: ProtectedApp) {
        apps.removeAll { $0.bundleID == app.bundleID }
        save()
    }

    func lockAllNow() {
        guard protectionEnabled, !apps.isEmpty else { return }
        var closedCount = 0
        for protectedApp in apps {
            for runningApp in NSRunningApplication.runningApplications(withBundleIdentifier: protectedApp.bundleID) {
                if runningApp.terminate() { closedCount += 1 }
            }
        }
        status = closedCount == 0
            ? "No protected apps are currently open."
            : "Lock requested for \(closedCount) protected app\(closedCount == 1 ? "" : "s")."
    }

    private func save() {
        if let data = try? JSONEncoder().encode(apps) { UserDefaults.standard.set(data, forKey: defaultsKey) }
    }

    private func saveSchedules() {
        guard let data = try? JSONEncoder().encode(schedules) else { return }
        UserDefaults.standard.set(data, forKey: "protectionSchedules")
    }

    func refreshProStatus() {
        let defaults = UserDefaults.standard
        var expiration = defaults.object(forKey: proExpirationKey) as? Date
        if expiration == nil, defaults.bool(forKey: "touchguard.pro") {
            expiration = Calendar.current.date(byAdding: .month, value: 3, to: Date())
            if let expiration { defaults.set(expiration, forKey: proExpirationKey) }
        }
        proExpirationDate = expiration
        isPro = expiration.map { $0 > Date() } ?? false
        defaults.set(isPro, forKey: "touchguard.pro")
        UserDefaults(suiteName: "com.codex.touchguard")?.set(expiration, forKey: "proExpirationDate")
    }
}

enum BackgroundAgentInstaller {
    private static let label = "com.codex.touchguard.agent"
    private static var plistURL: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/LaunchAgents", isDirectory: true)
            .appendingPathComponent("\(label).plist")
    }
    static var isInstalled: Bool { FileManager.default.fileExists(atPath: plistURL.path) }

    static func install() -> String {
        let executable = Bundle.main.bundleURL
            .appendingPathComponent("Contents/Library/LoginItems/TouchGuardAgent.app/Contents/MacOS/TouchGuardAgent")
        let agentsDirectory = plistURL.deletingLastPathComponent()
        let plist: [String: Any] = [
            "Label": label,
            "ProgramArguments": [executable.path],
            "RunAtLoad": true,
            "KeepAlive": true,
            "LimitLoadToSessionType": "Aqua"
        ]
        do {
            try FileManager.default.createDirectory(at: agentsDirectory, withIntermediateDirectories: true)
            let data = try PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0)
            try data.write(to: plistURL, options: .atomic)
            let unload = Process()
            unload.executableURL = URL(fileURLWithPath: "/bin/launchctl")
            unload.arguments = ["bootout", "gui/\(getuid())", plistURL.path]
            try unload.run()
            unload.waitUntilExit()
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/bin/launchctl")
            process.arguments = ["bootstrap", "gui/\(getuid())", plistURL.path]
            try process.run()
            process.waitUntilExit()
            if process.terminationStatus == 0 {
                return "Background protection is running and will restart at login."
            }
            // A nonzero result commonly means this LaunchAgent is already loaded.
            let kickstart = Process()
            kickstart.executableURL = URL(fileURLWithPath: "/bin/launchctl")
            kickstart.arguments = ["kickstart", "gui/\(getuid())/\(label)"]
            try kickstart.run()
            kickstart.waitUntilExit()
            return kickstart.terminationStatus == 0
                ? "Background protection is running and will restart at login."
                : "Could not start background protection. Reopen TouchGuard to try again."
        } catch {
            return "Could not install background protection: \(error.localizedDescription)"
        }
    }

    static func uninstall() -> String {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/bin/launchctl")
        process.arguments = ["bootout", "gui/\(getuid())", plistURL.path]
        do {
            try process.run()
            process.waitUntilExit()
            try? FileManager.default.removeItem(at: plistURL)
            return "Protection is off. Protected apps will open without Touch ID."
        } catch {
            return "Could not turn off background protection: \(error.localizedDescription)"
        }
    }
}

@main
struct TouchGuardApp: App {
    @NSApplicationDelegateAdaptor(TouchGuardAppDelegate.self) private var appDelegate
    @StateObject private var model = GuardModel()

    var body: some Scene {
        WindowGroup(id: "main") {
            ContentView(model: model)
                .frame(minWidth: 620, minHeight: 560)
        }
        .windowResizability(.contentSize)

        MenuBarExtra("TouchGuard", systemImage: "touchid") {
            GuardMenu(model: model)
        }
        .menuBarExtraStyle(.menu)
    }
}

final class TouchGuardAppDelegate: NSObject, NSApplicationDelegate {
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        sender.activate(ignoringOtherApps: true)
        if !flag {
            for window in sender.windows where window.canBecomeMain {
                window.deminiaturize(nil)
                window.makeKeyAndOrderFront(nil)
            }
        }
        return true
    }
}

struct GuardMenu: View {
    @ObservedObject var model: GuardModel
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        Text(model.status)
            .lineLimit(2)
        Divider()
        Button(model.protectionEnabled ? "Turn Off Protection" : "Turn On Protection",
               systemImage: model.protectionEnabled ? "lock.open" : "lock.fill") {
            model.setProtectionEnabled(!model.protectionEnabled)
        }
        Button("Lock All Apps Now", systemImage: "lock.fill") { model.lockAllNow() }
            .disabled(model.apps.isEmpty || !model.protectionEnabled)
        Button("Open TouchGuard") { openWindow(id: "main") }
        Text("Closing this window leaves protection running.")
    }
}

struct ContentView: View {
    @ObservedObject var model: GuardModel

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            header
            overviewCard

            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Protected apps")
                        .font(.title2.weight(.semibold))
                    Text("Choose which apps ask for Touch ID.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button(action: model.lockAllNow) {
                    Label("Lock Now", systemImage: "lock.fill")
                }
                .disabled(model.apps.isEmpty || !model.protectionEnabled)
                Button(action: model.addApp) {
                    Label("Add App", systemImage: "plus")
                }
                .buttonStyle(.borderedProminent)
            }

            HStack(spacing: 12) {
                Label(model.proPlanLabel, systemImage: model.isPro ? "sparkles" : "lock.shield")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(model.isPro ? Color.accentColor : Color.secondary)
                Spacer()
                Button(model.isPro ? "Manage schedules" : "Schedules · Pro") {
                    model.requestSchedule()
                }
                .buttonStyle(.bordered)
                Button(model.isPro ? "Renew Pro" : "Upgrade to Pro") { model.showingPro = true }
                    .buttonStyle(.borderedProminent)
            }

            if model.apps.isEmpty {
                emptyState
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(model.apps.enumerated()), id: \.element.id) { index, app in
                        appRow(app)
                        if index < model.apps.count - 1 {
                            Divider().padding(.leading, 62)
                        }
                    }
                }
                .padding(.horizontal, 14)
                .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 16))
                .overlay {
                    RoundedRectangle(cornerRadius: 16)
                        .strokeBorder(Color.primary.opacity(0.06), lineWidth: 1)
                }
            }

            Spacer(minLength: 0)
            footer
        }
        .padding(28)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color(nsColor: .windowBackgroundColor))
        .sheet(isPresented: $model.showingPro) { ProUpgradeView(model: model) }
        .sheet(isPresented: $model.showingSchedule) { ScheduleView(model: model) }
    }

    private var header: some View {
        HStack(spacing: 14) {
            Image(systemName: "touchid")
                .font(.system(size: 27, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: 54, height: 54)
                .background(
                    LinearGradient(colors: [Color.accentColor, Color.accentColor.opacity(0.72)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                    in: RoundedRectangle(cornerRadius: 16, style: .continuous)
                )
            VStack(alignment: .leading, spacing: 3) {
                Text("TouchGuard")
                    .font(.system(size: 25, weight: .bold, design: .rounded))
                Text("Private access for your Mac apps")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button(action: { model.setProtectionEnabled(!model.protectionEnabled) }) {
                HStack(spacing: 7) {
                    Circle().fill(model.protectionEnabled ? Color.green : Color.secondary).frame(width: 8, height: 8)
                    Text(model.protectionEnabled ? "Protection on" : "Turn protection on")
                        .font(.caption.weight(.semibold))
                }
                .padding(.horizontal, 11)
                .padding(.vertical, 8)
                .background((model.protectionEnabled ? Color.green : Color.secondary).opacity(0.10), in: Capsule())
                .foregroundStyle(model.protectionEnabled ? Color.green : Color.secondary)
            }
            .buttonStyle(.plain)
            .help(model.protectionEnabled ? "Turn protection off" : "Enable background protection")
        }
    }

    private var overviewCard: some View {
        HStack(spacing: 0) {
            overviewMetric(value: "\(model.apps.count)", title: "Apps selected", icon: "lock.shield.fill")
            Rectangle().fill(Color.primary.opacity(0.08)).frame(width: 1, height: 42)
            overviewMetric(value: "Touch ID", title: "Unlock method", icon: "touchid")
            Spacer(minLength: 10)
            Image(systemName: "checkmark.seal.fill")
                .font(.system(size: 25))
                .foregroundStyle(.green.opacity(0.85))
                .padding(.trailing, 4)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 17)
        .background(Color.accentColor.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .strokeBorder(Color.accentColor.opacity(0.10), lineWidth: 1)
        }
    }

    private func overviewMetric(value: String, title: String, icon: String) -> some View {
        HStack(spacing: 11) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .medium))
                .foregroundStyle(Color.accentColor)
                .frame(width: 36, height: 36)
                .background(Color.accentColor.opacity(0.10), in: RoundedRectangle(cornerRadius: 11))
            VStack(alignment: .leading, spacing: 2) {
                Text(value).font(.headline)
                Text(title).font(.caption).foregroundStyle(.secondary)
            }
        }
        .frame(minWidth: 165, alignment: .leading)
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "lock.open.fill")
                .font(.system(size: 25, weight: .medium))
                .foregroundStyle(Color.accentColor)
                .frame(width: 58, height: 58)
                .background(Color.accentColor.opacity(0.09), in: RoundedRectangle(cornerRadius: 18))
            Text("No apps protected yet")
                .font(.headline)
            Text("Add an app to require Touch ID when it opens.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Button(action: model.addApp) {
                Label("Choose an App", systemImage: "plus")
            }
            .buttonStyle(.borderedProminent)
            .padding(.top, 2)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(24)
        .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 16))
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .strokeBorder(Color.primary.opacity(0.06), lineWidth: 1)
        }
    }

    private func appRow(_ app: ProtectedApp) -> some View {
        HStack(spacing: 13) {
            appIcon(for: app)
                .frame(width: 40, height: 40)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(app.name).font(.system(size: 14, weight: .semibold))
                Text(app.bundleID).font(.caption).foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 10)
            Image(systemName: "lock.fill")
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(Color.accentColor)
                .padding(8)
                .background(Color.accentColor.opacity(0.09), in: Circle())
            Button(role: .destructive) { model.remove(app) } label: {
                Image(systemName: "minus.circle")
                    .font(.system(size: 15))
            }
            .buttonStyle(.plain)
            .help("Remove protection")
        }
        .padding(.vertical, 11)
    }

    private var footer: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "checkmark.shield.fill")
                .foregroundStyle(Color.accentColor)
            VStack(alignment: .leading, spacing: 3) {
                Text(model.status)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                Text("Protected apps close during authentication and reopen after you unlock.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(.top, 13)
        .overlay(alignment: .top) { Divider() }
    }

    @ViewBuilder
    private func appIcon(for app: ProtectedApp) -> some View {
        if let icon = NSWorkspace.shared.icon(forFile: app.path) as NSImage? {
            Image(nsImage: icon).resizable().frame(width: 32, height: 32)
        } else {
            Image(systemName: "app.fill").frame(width: 32, height: 32)
        }
    }
}

private struct ProUpgradeView: View {
    @ObservedObject var model: GuardModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "sparkles")
                .font(.system(size: 30, weight: .semibold))
                .foregroundStyle(Color.accentColor)
                .frame(width: 66, height: 66)
                .background(Color.accentColor.opacity(0.10), in: RoundedRectangle(cornerRadius: 20))
            Text(model.isPro ? "Renew TouchGuard Pro" : "Get TouchGuard Pro").font(.title2.bold())
            Text("Protect every app on your Mac and create schedules for when protection should be active.")
                .multilineTextAlignment(.center).foregroundStyle(.secondary)
            VStack(alignment: .leading, spacing: 12) {
                Label("Unlimited protected apps", systemImage: "checkmark.circle.fill")
                Label("Protection schedules", systemImage: "checkmark.circle.fill")
                Label("Three months of Pro per purchase", systemImage: "checkmark.circle.fill")
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14))
            if let expiration = model.proExpirationDate, model.isPro {
                Text("Active until \(expiration.formatted(date: .long, time: .omitted))")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Text("₹100 · 3 months")
                .font(.headline)
            if let qrURL = Bundle.main.url(forResource: "TouchGuardPro-UPI", withExtension: "png"),
               let qrImage = NSImage(contentsOf: qrURL) {
                Image(nsImage: qrImage)
                    .resizable()
                    .interpolation(.none)
                    .scaledToFit()
                    .frame(width: 190, height: 190)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.primary.opacity(0.10), lineWidth: 1))
                    .accessibilityLabel("PhonePe UPI payment QR code requesting ₹100")
            } else {
                Label("Payment QR unavailable", systemImage: "qrcode")
                    .foregroundStyle(.secondary)
            }

            VStack(spacing: 10) {
                Text("After you verify the payment, use this request code to issue a 3-month activation code.")
                    .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
                HStack(spacing: 8) {
                    Text(model.activationRequestCode)
                        .font(.system(.caption, design: .monospaced))
                        .lineLimit(1)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Button("Copy") {
                        NSPasteboard.general.clearContents()
                        NSPasteboard.general.setString(model.activationRequestCode, forType: .string)
                    }
                    .buttonStyle(.bordered)
                }
                SecureField("Activation code", text: $model.activationInput)
                    .textFieldStyle(.roundedBorder)
                Button(model.isPro ? "Renew Pro" : "Activate Pro") { model.activatePro(with: model.activationInput) }
                    .buttonStyle(.borderedProminent)
                    .disabled(model.activationInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                if let message = model.proActivationMessage {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(model.isPro ? Color.green : Color.red)
                        .multilineTextAlignment(.center)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity)
            .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14))
            Button(model.isPro ? "Done" : "Maybe later") { dismiss() }.buttonStyle(.plain)
        }
        .padding(28).frame(width: 410)
    }
}

private struct ScheduleView: View {
    @ObservedObject var model: GuardModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(spacing: 12) {
                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 25, weight: .medium))
                    .foregroundStyle(Color.accentColor)
                    .frame(width: 48, height: 48)
                    .background(Color.accentColor.opacity(0.10), in: RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading, spacing: 3) {
                    Text("Protection schedules").font(.title2.bold())
                    Text("Create weekly times when TouchGuard protects your apps.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }
            if model.schedules.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "calendar.badge.clock").font(.system(size: 28)).foregroundStyle(Color.accentColor)
                    Text("No schedules yet").font(.headline)
                    Text("Add a weekly schedule to choose when app protection is active.")
                        .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity, minHeight: 150)
            } else {
                ScrollView {
                    VStack(spacing: 12) {
                        ForEach(model.schedules) { schedule in
                            ScheduleEditorRow(schedule: schedule,
                                              onChange: model.updateSchedule,
                                              onDelete: { model.removeSchedule(schedule.id) })
                        }
                    }
                }
                .frame(maxHeight: 390)
            }

            HStack {
                Button {
                    model.addSchedule()
                } label: {
                    Label("Add Schedule", systemImage: "plus")
                }
                Spacer()
                Button("Done") { dismiss() }.buttonStyle(.borderedProminent)
            }
        }
        .padding(26).frame(width: 470).frame(minHeight: 300)
    }
}

private struct ScheduleEditorRow: View {
    let schedule: ProtectionSchedule
    let onChange: (ProtectionSchedule) -> Void
    let onDelete: () -> Void

    private let weekdays: [(title: String, value: Int)] = [
        ("M", 2), ("T", 3), ("W", 4), ("T", 5), ("F", 6), ("S", 7), ("S", 1)
    ]

    init(schedule: ProtectionSchedule, onChange: @escaping (ProtectionSchedule) -> Void, onDelete: @escaping () -> Void) {
        self.schedule = schedule
        self.onChange = onChange
        self.onDelete = onDelete
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack(spacing: 10) {
                TextField("Schedule name", text: Binding(
                    get: { schedule.name },
                    set: { value in var copy = schedule; copy.name = value; onChange(copy) }
                ))
                .textFieldStyle(.roundedBorder)
                Toggle("On", isOn: Binding(
                    get: { schedule.isEnabled },
                    set: { value in var copy = schedule; copy.isEnabled = value; onChange(copy) }
                ))
                .toggleStyle(.switch)
                Button(role: .destructive, action: onDelete) {
                    Image(systemName: "trash")
                }
                .buttonStyle(.plain)
                .help("Delete schedule")
            }

            HStack(spacing: 7) {
                ForEach(weekdays, id: \.value) { day in
                    Button {
                        var copy = schedule
                        if copy.days.contains(day.value) {
                            guard copy.days.count > 1 else { return }
                            copy.days.remove(day.value)
                        }
                        else { copy.days.insert(day.value) }
                        onChange(copy)
                    } label: {
                        Text(day.title)
                            .font(.caption.weight(.semibold))
                            .frame(width: 31, height: 31)
                            .background(schedule.days.contains(day.value) ? Color.accentColor : Color(nsColor: .controlBackgroundColor), in: Circle())
                            .foregroundStyle(schedule.days.contains(day.value) ? Color.white : Color.primary)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(Calendar.current.weekdaySymbols[day.value - 1])
                    .accessibilityAddTraits(schedule.days.contains(day.value) ? .isSelected : [])
                }
                Spacer()
                timePicker("Start", minute: schedule.startMinute) { value in var copy = schedule; copy.startMinute = value; onChange(copy) }
                Image(systemName: "arrow.right").foregroundStyle(.tertiary)
                timePicker("End", minute: schedule.endMinute) { value in var copy = schedule; copy.endMinute = value; onChange(copy) }
            }
            Text("Outside this schedule, apps open without Touch ID.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .padding(14)
        .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14))
    }

    private func timePicker(_ title: String, minute: Int, update: @escaping (Int) -> Void) -> some View {
        DatePicker(title, selection: Binding(
            get: { Calendar.current.date(bySettingHour: minute / 60, minute: minute % 60, second: 0, of: Date()) ?? Date() },
            set: { date in
                let parts = Calendar.current.dateComponents([.hour, .minute], from: date)
                update((parts.hour ?? 9) * 60 + (parts.minute ?? 0))
            }
        ), displayedComponents: .hourAndMinute)
        .labelsHidden()
        .datePickerStyle(.compact)
    }
}
