// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "TouchGuard",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "TouchGuardApp", targets: ["TouchGuard"]),
        .executable(name: "TouchGuard", targets: ["TouchGuardAgent"])
    ],
    targets: [
        .executableTarget(name: "TouchGuard"),
        .executableTarget(name: "TouchGuardAgent")
    ]
)
